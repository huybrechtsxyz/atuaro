# Atuaro: D&Dave 2023 - To level 2

Our heroes cleared the silverpine watch and are on their way to Loukotokia