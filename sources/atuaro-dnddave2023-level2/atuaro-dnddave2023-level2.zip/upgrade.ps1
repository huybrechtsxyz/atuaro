. ./sources/upgrade.ps1

Update-FoundryModule -WorkspacePath "./adventures/dndave2023level2" -SourcePath "./sources/atuaro-dnddave2023-level2"