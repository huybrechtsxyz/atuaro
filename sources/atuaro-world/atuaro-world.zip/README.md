# Atuaro: The World

The basic module for Atuaro. Install this module if you want to use any other module for Atuaro.