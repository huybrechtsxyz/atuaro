. ./sources/upgrade.ps1

Upgrade-FoundryModule -WorkspacePath "./adventures/gauntlet" -SourcePath "./sources/atuaro-gauntlet"