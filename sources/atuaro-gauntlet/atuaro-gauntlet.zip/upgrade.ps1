. ../upgrade.ps1

Upgrade-Foundry-Module -SourcePath . -WorkspacePath "..\..\adventures\gauntlet"