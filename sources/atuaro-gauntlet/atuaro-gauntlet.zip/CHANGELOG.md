# Atuaro: Picking up the Gauntlet

## 1.0
The first version of the adventure.