# Atuaro: Picking up the Gauntlet

Our heroes return after 10 years to Kainga and notice that things are changed. The orphanage burned down and there is no sight of Ms Witchling or the offspring. Recently, there has been an in influx of goblins in the region and some of the foul creatures have even begun attacking the farms in the outskirts of the village of Kainga.