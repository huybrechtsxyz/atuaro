. ../update.ps1

Update-Foundry-Module