. ./sources/upgrade.ps1

Update-FoundryModule -SourcePath "./sources/atuaro-world"