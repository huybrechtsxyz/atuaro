. ./sources/upgrade.ps1

Update-FoundryModule -WorkspacePath "./adventures/gauntlet" -SourcePath "./sources/atuaro-gauntlet"